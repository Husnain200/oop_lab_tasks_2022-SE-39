#include <iostream>
using namespace std;

// Calculator Class
class Calculator
{
public:
    int add(int a, int b)
    {
        return a + b;
    }

    int multiply(int a, int b)
    {
        return a * b;
    }
};

// Student Class
class Student
{
private:
    string name;

    // Aggregation
    Calculator *calculator;

public:
    Student(string n, Calculator *c)
    {
        name = n;
        calculator = c;
    }

    void performAddition(int x, int y)
    {
        cout << name
             << " Addition Result = "
             << calculator->add(x, y)
             << endl;
    }

    void performMultiplication(int x, int y)
    {
        cout << name
             << " Multiplication Result = "
             << calculator->multiply(x, y)
             << endl;
    }
};

int main()
{
    // Shared Calculator
    Calculator sharedCalculator;

    // Students using same calculator
    Student s1("Ali", &sharedCalculator);
    Student s2("Ahmed", &sharedCalculator);

    s1.performAddition(5, 2);

    s2.performMultiplication(4, 3);

    return 0;
}
