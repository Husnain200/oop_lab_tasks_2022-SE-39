#include <iostream>
using namespace std;

// Structure Declaration
struct Student
{
    string firstName;
    string lastName;
    int rollNumber;
    float marks;

    // Member Function
    void displayStudentInfo()
    {
        cout << "Student Full Name: "
             << firstName << " " << lastName << endl;

        cout << "Roll Number: "
             << rollNumber << endl;

        cout << "Marks: "
             << marks << endl;
    }
};

int main()
{
    // Structure Variable
    Student s1;

    // Assigning Values
    s1.firstName = "Ali";
    s1.lastName = "Khan";
    s1.rollNumber = 101;
    s1.marks = 89.5;

    // Calling Member Function
    s1.displayStudentInfo();

    return 0;
}
