#include <iostream>
using namespace std;

// Base Class
class Employee
{
protected:
    string name;
    double salary;

public:
    void input_employee()
    {
        cout << "Enter Employee Name: ";
        cin >> name;

        cout << "Enter Salary: ";
        cin >> salary;
    }

    void display_employee()
    {
        cout << "\nName: " << name << endl;
        cout << "Salary: " << salary << endl;
    }
};

// Derived Class 1
class Developer : public Employee
{
private:
    string programming_language;

public:
    void input_developer()
    {
        cout << "Enter Programming Language: ";
        cin >> programming_language;
    }

    void display_developer()
    {
        cout << "Programming Language: "
             << programming_language << endl;
    }
};

// Derived Class 2
class Designer : public Employee
{
private:
    string design_tool;

public:
    void input_designer()
    {
        cout << "Enter Design Tool: ";
        cin >> design_tool;
    }

    void display_designer()
    {
        cout << "Design Tool: "
             << design_tool << endl;
    }
};

int main()
{
    Developer d1;
    Designer d2;

    cout << "\n--- Developer Information ---" << endl;

    d1.input_employee();
    d1.input_developer();

    d1.display_employee();
    d1.display_developer();

    cout << "\n--- Designer Information ---" << endl;

    d2.input_employee();
    d2.input_designer();

    d2.display_employee();
    d2.display_designer();

    return 0;
}
