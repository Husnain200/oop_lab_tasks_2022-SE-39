#include <iostream>
using namespace std;

class Temperature
{
public:
    float celsius;
    float fahrenheit;

    void convert()
    {
        fahrenheit = (9.0 / 5.0) * celsius + 32;
    }

    void display()
    {
        cout << "Temperature in Fahrenheit = "
             << fahrenheit << endl;
    }
};

int main()
{
    Temperature t1;

    cout << "Enter Temperature in Celsius: ";
    cin >> t1.celsius;

    t1.convert();
    t1.display();

    return 0;
}
