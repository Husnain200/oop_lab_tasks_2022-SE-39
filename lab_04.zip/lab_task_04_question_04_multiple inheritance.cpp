#include <iostream>
using namespace std;

// Base Class 1
class Printer
{
public:
    void print_document()
    {
        cout << "Printing Document..." << endl;
    }
};

// Base Class 2
class Scanner
{
public:
    void scan_document()
    {
        cout << "Scanning Document..." << endl;
    }
};

// Derived Class
class Photocopier : public Printer, public Scanner
{
public:
    void photocopy()
    {
        cout << "Photocopy Process Started..." << endl;

        print_document();
        scan_document();

        cout << "Photocopy Completed." << endl;
    }
};

int main()
{
    Photocopier p1;

    p1.print_document();
    p1.scan_document();
    p1.photocopy();

    return 0;
}
