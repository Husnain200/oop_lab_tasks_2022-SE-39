#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream file("notes.txt");

    string line;
    int count = 0;

    while(getline(file, line))
    {
        count++;
    }

    file.close();

    cout << "Total Number of Lines = "
         << count << endl;

    return 0;
}
