#include <iostream>
using namespace std;

// Structure Declaration
struct Student
{
    string firstName;
    string lastName;
    int rollNumber;
    float marks;

    // Member Function
    void displayStudentInfo()
    {
        cout << "\n----- Student Information -----" << endl;

        cout << "Full Name: "
             << firstName << " " << lastName << endl;

        cout << "Roll Number: "
             << rollNumber << endl;

        cout << "Marks: "
             << marks << endl;
    }
};

int main()
{
    // Dynamically creating structure using pointer
    Student *ptr = new Student;

    // Assigning values using pointer
    ptr->firstName = "Ali";
    ptr->lastName = "Khan";
    ptr->rollNumber = 101;
    ptr->marks = 88.5;

    // Calling member function using pointer
    ptr->displayStudentInfo();

    // Free memory
    delete ptr;

    return 0;
}
