#include <iostream>
using namespace std;

// Display Class
class Display
{
private:
    int lastResult;

public:
    Display()
    {
        lastResult = 0;
    }

    void showResult(int result)
    {
        lastResult = result;

        cout << "Result = "
             << lastResult << endl;
    }

    int getLastResult()
    {
        return lastResult;
    }
};

// Calculator Class
class Calculator
{
private:
    // Composition
    Display display;

public:
    int add(int a, int b)
    {
        int result = a + b;

        display.showResult(result);

        return result;
    }

    int multiply(int a, int b)
    {
        int result = a * b;

        display.showResult(result);

        return result;
    }

    void showLastResult()
    {
        cout << "Last Result = "
             << display.getLastResult() << endl;
    }
};

int main()
{
    Calculator c1;

    c1.add(5, 3);

    c1.multiply(4, 2);

    c1.showLastResult();

    return 0;
}
