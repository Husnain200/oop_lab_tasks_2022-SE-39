#include <iostream>
using namespace std;

class Product
{
private:
    string name;
    double price;
    int quantity;

public:

    // Setter for Name
    void setName(string n)
    {
        if(n != "")
        {
            name = n;
        }
        else
        {
            cout << "Invalid Name!" << endl;
        }
    }

    // Setter for Price
    void setPrice(double p)
    {
        if(p > 0)
        {
            price = p;
        }
        else
        {
            cout << "Price must be greater than 0!" << endl;
        }
    }

    // Setter for Quantity
    void setQuantity(int q)
    {
        if(q >= 0)
        {
            quantity = q;
        }
        else
        {
            cout << "Quantity cannot be negative!" << endl;
        }
    }

    // Getters
    string getName()
    {
        return name;
    }

    double getPrice()
    {
        return price;
    }

    int getQuantity()
    {
        return quantity;
    }
};

int main()
{
    Product p1;

    // Setting Values
    p1.setName("Laptop");
    p1.setPrice(85000);
    p1.setQuantity(5);

    // Displaying Values
    cout << "\n--- Product Information ---" << endl;

    cout << "Product Name: "
         << p1.getName() << endl;

    cout << "Price: "
         << p1.getPrice() << endl;

    cout << "Quantity: "
         << p1.getQuantity() << endl;

    return 0;
}
