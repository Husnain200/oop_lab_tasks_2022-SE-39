#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    // Writing Student Details
    ofstream outFile("students.txt");

    outFile << "Ali 101" << endl;
    outFile << "Ahmed 102" << endl;
    outFile << "Sara 103" << endl;

    outFile.close();

    // Reading Student Details
    ifstream inFile("students.txt");

    string name;
    int rollNumber;

    cout << "Student Details:\n" << endl;

    while(inFile >> name >> rollNumber)
    {
        cout << "Name: "
             << name
             << " | Roll Number: "
             << rollNumber << endl;
    }

    inFile.close();

    return 0;
}
