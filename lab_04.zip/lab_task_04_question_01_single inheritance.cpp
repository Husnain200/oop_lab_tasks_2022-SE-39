#include <iostream>
using namespace std;

// Base Class
class Person
{
protected:
    string name;
    int age;

public:
    void input_person()
    {
        cout << "Enter Name: ";
        cin >> name;

        cout << "Enter Age: ";
        cin >> age;
    }

    void display_person_info()
    {
        cout << "\n--- Person Information ---" << endl;
        cout << "Name: " << name << endl;
        cout << "Age: " << age << endl;
    }
};

// Derived Class
class Student : public Person
{
private:
    int student_id;

public:
    void input_student()
    {
        cout << "Enter Student ID: ";
        cin >> student_id;
    }

    void display_student_info()
    {
        cout << "Student ID: " << student_id << endl;
    }
};

int main()
{
    Student s1;

    s1.input_person();
    s1.input_student();

    s1.display_person_info();
    s1.display_student_info();

    return 0;
}
