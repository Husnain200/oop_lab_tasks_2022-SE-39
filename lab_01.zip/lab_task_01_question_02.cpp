#include <iostream>
using namespace std;

// Structure Declaration
struct Student
{
    string firstName;
    string lastName;
    int rollNumber;
    float marks;

    // Member Function
    void displayStudentInfo()
    {
        cout << "\n----- Student Information -----" << endl;

        cout << "Full Name: "
             << firstName << " " << lastName << endl;

        cout << "Roll Number: "
             << rollNumber << endl;

        cout << "Marks: "
             << marks << endl;
    }
};

int main()
{
    int n;

    cout << "Enter number of students: ";
    cin >> n;

    // Array of Structures
    Student students[n];

    // Input Student Details
    for(int i = 0; i < n; i++)
    {
        cout << "\nEnter details for Student "
             << i + 1 << endl;

        cout << "First Name: ";
        cin >> students[i].firstName;

        cout << "Last Name: ";
        cin >> students[i].lastName;

        cout << "Roll Number: ";
        cin >> students[i].rollNumber;

        cout << "Marks: ";
        cin >> students[i].marks;
    }

    // Display Student Details
    cout << "\n\n===== Student Records =====" << endl;

    for(int i = 0; i < n; i++)
    {
        students[i].displayStudentInfo();
    }

    return 0;
}
