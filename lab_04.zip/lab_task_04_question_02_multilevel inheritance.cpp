#include <iostream>
using namespace std;

// Base Class
class Person
{
protected:
    string name;
    int age;

public:
    void input_person()
    {
        cout << "Enter Name: ";
        cin >> name;

        cout << "Enter Age: ";
        cin >> age;
    }

    void display_person()
    {
        cout << "\n--- Person Information ---" << endl;
        cout << "Name: " << name << endl;
        cout << "Age: " << age << endl;
    }
};

// Derived Class
class Employee : public Person
{
protected:
    int employee_id;

public:
    void input_employee()
    {
        cout << "Enter Employee ID: ";
        cin >> employee_id;
    }

    void display_employee()
    {
        cout << "Employee ID: "
             << employee_id << endl;
    }
};

// Derived from Employee
class Manager : public Employee
{
private:
    string department;

public:
    void input_manager()
    {
        cout << "Enter Department: ";
        cin >> department;
    }

    void display_manager()
    {
        cout << "Department: "
             << department << endl;
    }
};

int main()
{
    Manager m1;

    m1.input_person();
    m1.input_employee();
    m1.input_manager();

    m1.display_person();
    m1.display_employee();
    m1.display_manager();

    return 0;
}
