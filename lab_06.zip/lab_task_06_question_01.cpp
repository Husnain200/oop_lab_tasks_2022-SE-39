#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    // Step 1: Create and Write into File
    ofstream outFile("notes.txt");

    outFile << "C++ is a programming language." << endl;
    outFile << "File handling is important." << endl;
    outFile << "OOP makes programs organized." << endl;

    outFile.close();

    // Step 2: Read File
    ifstream inFile("notes.txt");

    string line;

    cout << "File Contents:\n" << endl;

    while(getline(inFile, line))
    {
        cout << line << endl;
    }

    inFile.close();

    // Step 3: Append Data
    ofstream appendFile("notes.txt", ios::app);

    appendFile << "Name: Ali" << endl;
    appendFile << "Roll Number: 101" << endl;

    appendFile.close();

    cout << "\nData Appended Successfully!" << endl;

    return 0;
}
