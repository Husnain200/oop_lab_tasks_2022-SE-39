#include <iostream>
using namespace std;

class Calculator
{
private:
    float num1;
    float num2;

public:
    void getNumbers();
    float add();
    float subtract();
    float multiply();
    float divide();
};

// Function Definitions

void Calculator::getNumbers()
{
    cout << "Enter First Number: ";
    cin >> num1;

    cout << "Enter Second Number: ";
    cin >> num2;
}

float Calculator::add()
{
    return num1 + num2;
}

float Calculator::subtract()
{
    return num1 - num2;
}

float Calculator::multiply()
{
    return num1 * num2;
}

float Calculator::divide()
{
    return num1 / num2;
}

int main()
{
    Calculator c1;
    int choice;

    c1.getNumbers();

    cout << "\n1. Add";
    cout << "\n2. Subtract";
    cout << "\n3. Multiply";
    cout << "\n4. Divide";

    cout << "\n\nEnter Your Choice: ";
    cin >> choice;

    switch(choice)
    {
        case 1:
            cout << "Result = " << c1.add();
            break;

        case 2:
            cout << "Result = " << c1.subtract();
            break;

        case 3:
            cout << "Result = " << c1.multiply();
            break;

        case 4:
            cout << "Result = " << c1.divide();
            break;

        default:
            cout << "Invalid Choice";
    }

    return 0;
}
